package kr.or.ddit.homework.homework16;

public class Stage {
	public int game(int result) {
		// TODO Auto-generated method stub
		return result;
	}
	public int gameMoney(int money, int result) {
		return money;
	}
}
